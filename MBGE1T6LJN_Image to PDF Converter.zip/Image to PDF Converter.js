const uploadBtn = document.getElementById("upload-btn");
const fileInput = document.getElementById("file-input");
const preview = document.getElementById("preview");
const convertBtn = document.getElementById("convert-btn");
const uploadArea = document.getElementById("upload-area");

let imageFiles = [];

uploadBtn.addEventListener("click", () => fileInput.click());

fileInput.addEventListener("change", handleFiles);
uploadArea.addEventListener("dragover", (e) => {
    e.preventDefault();
    uploadArea.style.borderColor = "green";
});

uploadArea.addEventListener("dragleave", () => {
    uploadArea.style.borderColor = "#aaa";
});

uploadArea.addEventListener("drop", (e) => {
    e.preventDefault();
    uploadArea.style.borderColor = "#aaa";
    handleFiles({
        target: {
            files: e.dataTransfer.files
        }
    });
});

function handleFiles(e) {
    const files = [...e.target.files];
    files.forEach((file) => {
        if (!file.type.startsWith("image/")) return;

        imageFiles.push(file);

        const reader = new FileReader();
        reader.onload = function(evt) {
            const img = document.createElement("img");
            img.src = evt.target.result;
            preview.appendChild(img);
        };
        reader.readAsDataURL(file);
    });
}

convertBtn.addEventListener("click", async () => {
    if (imageFiles.length === 0) {
        alert("Please upload at least one image.");
        return;
    }

    const {
        jsPDF
    } = window.jspdf;
    const pdf = new jsPDF();

    for (let i = 0; i < imageFiles.length; i++) {
        const imgData = await toDataURL(imageFiles[i]);
        if (i > 0) pdf.addPage();
        pdf.addImage(imgData, "JPEG", 10, 10, 190, 270);
    }

    pdf.save("images.pdf");
});

function toDataURL(file) {
    return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.readAsDataURL(file);
    });
}